export class Player{
    name: String;
    rank: Number;
    score: Number;
    time: String;
    game: String;
    status: String;
}