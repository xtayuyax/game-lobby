export class Game{
    title : String; 
    platform : String;
    genre : String;
    rating : Number; 
    publisher: String;
    release: Number;
    status : String
}